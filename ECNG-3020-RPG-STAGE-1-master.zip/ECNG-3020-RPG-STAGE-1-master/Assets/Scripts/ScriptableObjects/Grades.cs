using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class Grades : ScriptableObject
{
    public string initialValue;
    public string RuntimeValue;
}
